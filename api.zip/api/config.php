﻿<?php
/**
 * ActionSteps Counseling - API configuration
 * Generated deployment config. Do not commit to version control.
 */
return [
    'db' => [
        'host' => 'localhost',
        'name' => 'actionst_actionsteps',
        'user' => 'actionst_laura',
        'pass' => 'WRP1XRtsB7nAVnWD',
    ],
    'jwt_secret' => 'eyRhEzoUjgS5CHNLBrp3DkfVmauJtIZ7PY2XcGiKqsQnbWlOxd84TM9F0A6v1w',
];