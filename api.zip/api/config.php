﻿<?php
/**
 * ActionSteps Counseling - API configuration
 * Generated deployment config. Do not commit to version control.
 */
return [
    'db' => [
        'host' => 'localhost',
        'name' => 'nowicor1_actionstep',
        'user' => 'nowicor1_actionstep',
        'pass' => 'zipr041oq61e2vu6',
    ],
    'jwt_secret' => 'eyRhEzoUjgS5CHNLBrp3DkfVmauJtIZ7PY2XcGiKqsQnbWlOxd84TM9F0A6v1w',
];